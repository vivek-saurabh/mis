Sticky was created by Haymarket Media Group by DMT team
Developer: Mihhail Arhipov (drupal.org id: skein)
Reviewer:

Install
-------
1) Put the module directory into modules
folder in your Drupal installation.

2) Enable the module in admin/modules or using drush

3) Go to admin/config/user-interface/stickynav

4) Activate the themes you want a sticky navigation on

5) Place a jquery format selector into the Selector field for each activated
theme

6) This may not look good on every theme. You might have to adjust the styling
to make it look good.
