FakeObjects

Installation
============

This module requires the core CKEditor module.

1. Download the plugin from http://ckeditor.com/addon/fakeobjects at least version 4.5.11.
2. Place the plugin in the root libraries folder (/libraries).
3. Enable FakeObjects module in the Drupal admin.