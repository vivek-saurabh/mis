CONTENTS OF THIS FILE
---------------------
Adds an additional field to set the ID of a block.

INTRODUCTION
------------
Block ID allows users new add id and using for css design.


REQUIREMENTS
------------
https://drupal.org/project/block


CONFIGURATION
-------------
Administration » Structure » Block
Block configration - Block ID