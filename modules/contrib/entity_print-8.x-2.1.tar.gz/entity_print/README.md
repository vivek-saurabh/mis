# SUMMARY

Entity Print allows you to print any Drupal entity or view to PDF.

For a full description visit project page:
https://www.drupal.org/project/entity_print

Bug reports, feature suggestions and latest developments:
http://drupal.org/project/issues/entity_print

# REQUIREMENTS

* Composer

# INSTALLATION

See documentation at https://www.drupal.org/project/entity_print and
https://www.drupal.org/node/2706755
